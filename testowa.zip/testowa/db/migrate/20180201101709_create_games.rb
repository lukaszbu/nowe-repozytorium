class CreateGames < ActiveRecord::Migration[5.1]
  def change
    create_table :games do |t|
      t.text :name
      t.integer :player_id
      t.references :player, foreign_key: true

      t.timestamps
    end
    add_index :games, [:player_id, :created_at]
  end
end
