class HomeController < ApplicationController
  def index
  def about
  end
  end
end