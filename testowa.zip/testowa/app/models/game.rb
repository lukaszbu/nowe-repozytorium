class Game < ApplicationRecord
  belongs_to :player
  validates :player_id, presence: true
   validates :name, presence: true, length: { maximum: 140 }
     default_scope -> { order(created_at: :desc) }

end
