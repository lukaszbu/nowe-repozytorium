class Player < ApplicationRecord
	has_many :games
	
end
