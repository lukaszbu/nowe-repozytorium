require "application_system_test_case"

class PlayersTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit players_url
  #
  #   assert_selector "h1", text: "Player"
  # end
end
