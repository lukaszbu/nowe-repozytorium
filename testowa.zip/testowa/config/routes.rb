Rails.application.routes.draw do
  get 'static_pages/home'
  get 'static_pages/about'
  # root 'static_pages#home'
  get 'static_pages/help'

  resources :games
  resources :players
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
 root 'home#index'
  get 'home/about'
  get "/about" => "home#about"


  
end
